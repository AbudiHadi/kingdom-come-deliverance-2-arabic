Kingdom Come: Deliverance II — Arabic translation, v1.0.0
Translation: Abdullah Hadi (عبدالله هادي)

=============================================
     About this translation
=============================================

- Complete Arabic text for the whole game and both expansions: dialogue and
  subtitles, menus and settings, quests and the journal, items, characters,
  skills and the codex, tutorials, minigames.
- The translation is joint work between AI and human review: every line was
  translated, then independently reviewed before it was accepted.
- All engine work (fonts, right-to-left rendering, build and install tooling)
  by Lexara (formerly RTL Forge).
- Manual installation only: three files copied into the game folder.
- Audio stays in English; only the text is translated.

=============================================
     Manual install (two minutes)
=============================================

1) Close the game.
2) In Steam: right-click the game -> Manage -> Browse local files.
3) Copy the contents of the zip into the game folder as they are:
   Localization\Arabic_xml.pak
   Mods\arabic\mod.manifest
   Mods\arabic\Data\arabic.pak
   (nothing is replaced: the three files are ADDED to the game)
4) Start the game, then: Settings -> Text Language -> العربية

Important: keep the file names and paths exactly as they are. A file in another
place or under another name is ignored by the game.

=============================================
     Notes and known limits
=============================================

- Upgrading from an earlier release: replace the three files the same way.
- A game update may switch the text back to English: copy the three files
  again after the update. If the update changed the game's text, wait for an
  updated translation.
- Do not combine this translation with other mods that change the UI fonts,
  and keep it last in the mod load order.
- The Arabic text in this package is tied to its fonts: copying or editing the
  text outside this package gives unreadable text.

=============================================
     Uninstall / rollback
=============================================

Delete the three files you copied (the Mods\arabic folder and
Localization\Arabic_xml.pak), or in Steam: Properties -> Installed Files ->
Verify integrity of game files.

=============================================
     Rights
=============================================

This translation is the work of Abdullah Hadi. Do not redistribute it or
credit it to anyone else.
